package com.bumbalbee.dao;

public interface DbConnectorFactory {
	
	DbConnector getDbConnector(); 
	
}
